package main

type Connection interface {
	Read([]byte) (int, error)
	Write([]byte) error
}

type TCP struct{}

func SendStringToConn(value string, conn Connection) {
	err := conn.Write([]byte(value))
	if err != nil {
		panic(err)
	}
}

func (t *TCP) Read(dest []byte) (int, error) {
	// implement read from tcp socket
	return 0, nil
}

func (t *TCP) Write(input []byte) error {
	// implement write to tcp socket
	return nil
}

func main() {
	tcpSocket := &TCP{}
	a := "Hello world!"
	SendStringToConn(a, tcpSocket)
}
