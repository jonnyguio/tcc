package main

import (
    "fmt"
    "time"
)

func processData() {
    // Pega dados de um servidor remoto e processa-os
}

func main() {
    go func() {
        for {
            fmt.Println("working...")
            time.Sleep(30 * time.Second)
        }
    }
    processData()
}
