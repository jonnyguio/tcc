package main

import "fmt"

func main() {
    a := 10
    if a < 10 {
        fmt.Println("'a' menor que 10")
    }
    if a < 5 {
        fmt.Println("'a' menor que 5")
    } else {
        fmt.Println("'a' maior que 5")
    }
    if b := a / 2; b < 10 {
        fmt.Println("'a/2' menor que 10")
    }
}