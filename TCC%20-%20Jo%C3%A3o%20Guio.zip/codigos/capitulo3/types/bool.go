package main

import "fmt"

func main() {
	var a int64
	var b complex128
	var c float64
	a = 100
	b = 1 + 10i
	c = 10.99999999999999
	fmt.Println(complex(float64(a), 0) + b)
	fmt.Println(float64(a) + c)
}
