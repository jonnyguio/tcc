package main

import "fmt"

type Vector interface {
	Sum(Vector) Vector
}

type Vector2 struct {
	x, y float64
}

func (v Vector2) Sum(v2 Vector2) Vector2 {
	return Vector2{v.x + v2.x, v.y + v2.y}
}

func main() {
	v1 := Vector2{1, 1}
	fmt.Println(v1.Sum(Vector2{10, 10}))
}
