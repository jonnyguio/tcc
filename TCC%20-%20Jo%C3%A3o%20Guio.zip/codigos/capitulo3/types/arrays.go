package main

import "fmt"

func main() {
	odds := [5]int{1, 3, 5, 7, 9}

	var firstThreeOdds []int = odds[0:3]
	fmt.Println(firstThreeOdds)
}
