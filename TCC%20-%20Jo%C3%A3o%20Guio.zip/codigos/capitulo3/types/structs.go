package main

import "fmt"

type foo struct {
	Bar string
	Baz int
}

func main() {
	v := &foo{"Hello", 1}

	fmt.Printf("%+v\n", v)
}
