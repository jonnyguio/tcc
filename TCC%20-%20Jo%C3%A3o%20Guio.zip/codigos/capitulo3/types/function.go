package main

import "fmt"

func multiplication(a int, x int) int {
	return a * x
}

func main() {
	x := 2
	fmt.Println(multiplication(10, x))
}
