package main

import "fmt"

func main() {
	var a int64
	var b float64
	c := 10
	a = 20
	b = 10.9999999999
	fmt.Println(int(a) + c)
	fmt.Println(float64(a) + b)
}
