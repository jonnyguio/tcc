package main

import "fmt"

func main() {
	ch, ch2 := make(chan int), make(chan int)
	go func() {
		ch <- 10
	}()
	go func() {
		ch <- 20
	}()
	select {
	case n := <-ch:
		fmt.Printf("Received value %d\n", n)
	case n := <-ch2:
		fmt.Printf("Received value %d\n", n)
	default:
		fmt.Println("Couldn't read from any channel")
	}
}
