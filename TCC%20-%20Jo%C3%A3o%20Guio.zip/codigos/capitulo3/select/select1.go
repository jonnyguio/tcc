package main

func getLastTemperatureValue() float32 {
    // reads from sensor
}

func getLastMoistureValue() float32 {
    // reads from sensor
} 

func processTemperature(temp float32) {
    // send to server
}

func processMoisture(moisture float32) {
    // send to server
}

func readTemperature(temperatureCh chan float32) {
	// ...
	for {
	    temperatureCh <- getLastTemperatureValue() // 
	}
}

func readMoisture(moistureCh chan float32) {
	// ...
	for {
	    moistureCh  <- getLastMoistureValue() // 
	}
}

func main() {
	tempChannel := make(chan float32)
	moistureChannel := make(chan float32)
	go readMoisture(moistureChannel)
	go readTemperature(tempChannel)
	for {
		select {
		case temp := <-tempChannel:
			processTemperature(temp) //
		case moisture := <-moistureChannel:
			processMoisture(moisture) // 
		}
	}
}
