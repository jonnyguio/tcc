package main

import (
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"time"
)

type philosopher struct {
	ID                  int
	LeftFork, RightFork *fork
}

type fork struct {
	ID    int
	dirty bool
	Send  chan *fork
}

var forks []*fork
var numPhilosophers int