func (p *philosopher) handleForks() {
    select {
    case p.LeftFork.Send <- p.LeftFork:
        if p.LeftFork.dirty {
            p.LeftFork.dirty = false
            p.LeftFork = &fork{ID: 0}
        }
    case p.RightFork.Send <- p.RightFork:
        if p.RightFork.dirty {
            p.RightFork.dirty = false
            p.RightFork = &fork{ID: 0}
        }
    default:
    }
    for p.LeftFork.ID == 0 || p.RightFork.ID == 0 {
        select {
        case p.LeftFork.Send <- p.LeftFork:
            if p.LeftFork.dirty {
                p.LeftFork.dirty = false
                p.LeftFork = &fork{ID: 0}
            }
        case p.RightFork.Send <- p.RightFork:
            if p.RightFork.dirty {
                p.RightFork.dirty = false
                p.RightFork = &fork{ID: 0}
            }
        case fork := <-forks[p.ID-1].Send:
            if fork.dirty {
                p.LeftFork = fork
            }
        case fork := <-forks[p.ID%numPhilosophers].Send:
            if fork.dirty {
                p.RightFork = fork
            }
        }
    }
}