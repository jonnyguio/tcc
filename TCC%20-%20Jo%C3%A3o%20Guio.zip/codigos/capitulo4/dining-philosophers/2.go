func (p *philosopher) start() {
    fmt.Println("Starting philosopher", p.ID)
    for {
        fmt.Println("Philosopher", p.ID, "is thinking")
        time.Sleep(time.Millisecond * time.Duration(rand.Int()%4000))
        fmt.Println("Philosopher", p.ID, "finished thinking")
        fmt.Println("Philosopher", p.ID, "is trying to eat")
        
        p.handleForks()
        
        fmt.Println("Philosopher", p.ID, "started eating")
        time.Sleep(time.Second * 1)
        fmt.Println("Philosopher", p.ID, "finished eating")
        p.LeftFork.dirty, p.RightFork.dirty = true, true
    }
}
