func initForksAndPhilosophers(philosophers []*philosopher) {
	for k, v := range forks {
		if k%2 == 1 {
			philosophers[k-1].RightFork = v
		} else {
			philosophers[k].LeftFork = v
		}
	}
}

func main() {
	var err error
	if len(os.Args) < 2 {
		fmt.Printf("Usage: %s <number of philosophers>\n", os.Args[0])
		os.Exit(1)
	}
	numPhilosophers, err = strconv.Atoi(os.Args[1])
	if err != nil {
		panic(err)
	}
	philosophers := []*philosopher{}
	for i := 0; i < numPhilosophers; i++ {
		forks = append(forks, &fork{ID: i + 1, dirty: true, Send: make(chan *fork, 1)})
		philosopher := &philosopher{
			ID:        i + 1,
			RightFork: &fork{},
			LeftFork:  &fork{},
		}
		philosophers = append(philosophers, philosopher)
	}
	initForksAndPhilosophers(philosophers)
	for _, p := range philosophers {
		go p.start()
	}
	time.Sleep(time.Minute * 5)
}
