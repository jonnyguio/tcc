package main

import (
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"sync"
	"time"
)

type philosopher struct {
	ID                  int
	LeftFork, RightFork *fork
}

type fork struct {
	ID      int
	dirty   bool
	inUse   bool
	Request chan *philosopher
}

var forks []*fork
var numPhilosophers int

func (p *philosopher) checkRequest(left bool) {
	if left {
		select {
		case requester := <-p.LeftFork.Request:
			requester.RightFork = p.LeftFork
			p.LeftFork = nil
		default:
		}
	} else {
		select {
		case requester := <-p.RightFork.Request:
			requester.LeftFork = p.RightFork
			p.RightFork = nil
		default:
		}
	}
}

func (p *philosopher) start() {
	fmt.Println("Starting philosopher ", p.ID)
	wg := &sync.WaitGroup{}
	for {
		// time thinking
		time.Sleep(time.Millisecond * time.Duration(rand.Int()%4000))

		// must eat!
		if p.LeftFork != nil {
			p.checkRequest(true)
		}
		if p.RightFork != nil {
			p.checkRequest(false)
		}
		if p.LeftFork == nil {
			wg.Add(1)
			go func() {
				defer wg.Done()
				forks[p.ID-1].Request <- p
			}()
			wg.Wait()
		}
		if p.RightFork == nil {
			wg.Add(1)
			go func() {
				defer wg.Done()
				forks[(p.ID)%numPhilosophers].Request <- p
			}()
			wg.Wait()
		}

		// fixed time eating
		time.Sleep(time.Second * 1)

		p.checkRequest(true)
		p.checkRequest(false)
	}
}

func initForks(philosophers []*philosopher) {
	for k, v := range forks {
		if k%2 == 1 {
			philosophers[k-1].RightFork = v
		} else {
			philosophers[k].LeftFork = v
		}
	}
	for k, p := range philosophers {
		fmt.Println(k, p)
	}
}

func main() {
	var err error
	if len(os.Args) < 2 {
		fmt.Printf("Usage: %s <number of philosophers>\n", os.Args[0])
		os.Exit(1)
	}
	numPhilosophers, err = strconv.Atoi(os.Args[1])
	if err != nil {
		fmt.Println("Failed to convert matrix size as number")
		panic(err)
	}
	for i := 0; i < numPhilosophers; i++ {
		forks = append(forks, &fork{ID: i + 1, dirty: true, Request: make(chan *philosopher)})
		philosopher := &philosopher{
			ID: i + 1,
		}
		fmt.Printf("%d\n", philosopher.ID)
		philosophers = append(philosophers, philosopher)
	}
	initForks(philosophers)
	for i, p := range philosophers {
		fmt.Println(i)
		go p.start()
	}
	time.Sleep(time.Minute * 5)
}
