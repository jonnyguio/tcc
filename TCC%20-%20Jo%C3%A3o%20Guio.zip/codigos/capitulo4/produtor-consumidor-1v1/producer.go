package main

import (
	"math/rand"
	"fmt"
	"sync"
	"time"
)

func producer(stream chan []byte, streamSize int) {
	randomInput := make([]byte, streamSize)
	for {
		n, err := rand.Read(randomInput)
		fmt.Println("Producer writing randomInput")
		stream <- randomInput
	}
}