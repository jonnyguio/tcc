package main

import (
	"math/rand"
	"time"
	"sync"
)


func main() {
	wg := sync.WaitGroup{}
	rand.Seed(time.Now().UTC().UnixNano())
	streamSize := 32
	stream := make(chan []byte, 1)

	wg.Add(1)
	go consumer(stream, streamSize)
	go producer(stream, streamSize)
	wg.Wait()
}
