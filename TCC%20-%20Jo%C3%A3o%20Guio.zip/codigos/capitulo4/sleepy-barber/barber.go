package main

import (
	"fmt"
	"sync"
)

type Barber struct {
	ID         int
	ReadyToCut chan int
}

func (b *Barber) start(seatsMutex *sync.Mutex, customerReady chan int, seats *int) {
	fmt.Println("Barber", b.ID, "started...")
	for {
		fmt.Println("Waiting costumer to arrive")
		costumerID := <-customerReady
		fmt.Println("Costumer", costumerID, "has arrived")
		seatsMutex.Lock()
		*seats++
		b.ReadyToCut <- b.ID
		fmt.Println("Will now start to cut")
		seatsMutex.Unlock()
		// CUT HAIR HERE
	}

}
