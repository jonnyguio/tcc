package coroutines

type Coroutine struct {
	base          func(...interface{}) []interface{}
	yield         chan interface{}
	resume        chan interface{}
	dead, started bool
}

func Create(base func(*Coroutine, ...interface{}) []interface{}) *Coroutine {
	coro := &Coroutine{
		yield:   make(chan interface{}),
		resume:  make(chan interface{}),
		dead:    false,
		started: false,
	}
	coro.base = func(args ...interface{}) []interface{} {
		rets := base(coro, args...)
		coro.dead = true
		return coro.Yield(rets...)
	}
	return coro
}
