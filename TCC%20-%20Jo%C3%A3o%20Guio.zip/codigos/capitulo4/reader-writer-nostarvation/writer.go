package writer

import (
	"crypto/rand"
	"fmt"
	"sync"
)

type Writer struct {
	ID    int
	Mutex *sync.RWMutex
}

func (w *Writer) start(stream []byte, size int) {
	for {
		w.Mutex.Lock()
		fmt.Printf("Writer %d writing byte string %v\n", w.ID, stream)
		rand.Read(stream)
		w.Mutex.Unlock()
	}
}
