#include <cstdlib>

void MultiplyMatrix(int **A, int **B, int **C, int n, int threads, int id) {
    for (int i = id; i < n; i+=threads) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                C[i][j] = C[i][j] + A[i][k] * B[k][j];
            }
        }
    }
}

void InitMatrix(int **A, int n, bool random) {
    for (int i = 0; i < n; i++) {
        A[i] = (int*) malloc(sizeof(int) * n);
        for (int j = 0; j < n; j++) {
            if (random) {
                A[i][j] = rand() % 10000;
            } else {
                A[i][j] = 0;
            }
        }
    }
}