func receivePeople() {
    for {
        conn, err := server.Accept()
        if err != nil {
            panic(err)
        }
        go func(conn net.Conn) {
            reader := bufio.NewReader(conn)
            _, err = conn.Write([]byte("Welcome to the chat! Please, type your name!\n"))
            if err != nil {
                break
            }
            name, err := reader.ReadString('\n')
            if err != nil {
                break
            }
            name = name[:len(name)-2]
            if _, ok := clients[name]; ok {
                for {
                    temp := name + strconv.Itoa(int(rand.Int31n(10e07)))
                    if _, ok := clients[temp]; ok {
                        continue
                    }
                    name = temp
                    break
                }
            }
            clients[name] = conn
            log.Printf("New client: %s! There are %d clients on the chat\n", name, len(clients))
            
            messages <- fmt.Sprintf("O usuario %s entrou do chat.\n", name)
            for {
                message, err := reader.ReadString('\n')
                if err != nil {
                    break
                }
                messages <- fmt.Sprintf("[%s]: %s", name, message)
            }
            dead <- name
        }(conn)
    }
}