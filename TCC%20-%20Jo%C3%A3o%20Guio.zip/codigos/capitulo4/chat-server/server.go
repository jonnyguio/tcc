package main

import (
	"bufio"
	"fmt"
	"log"
	"math/rand"
	"net"
	"strconv"
	"time"
)

func main() {
    server, err := net.Listen("tcp", ":3000")
    if err != nil {
        panic(err)
    }
    clients := make(map[string]net.Conn)
    dead := make(chan string)
    messages := make(chan string)
    rand.Seed(time.Now().UTC().UnixNano())
    go receivePeople()
    for {
        select {
        case message := <-messages:
            for name, conn := range clients {
                go func(conn net.Conn) {
                    _, err := conn.Write([]byte(message))
                    if err != nil {
                        dead <- name
                    }
                }(conn)
            }
            log.Printf("New message: \"%s\". Broadcast to %d clients\n", message[:len(message)-2], len(clients))
        case name := <-dead:
            go func() {
                log.Printf("Client %s disconnected\n", name)
                delete(clients, name)
                messages <- fmt.Sprintf("O usuario %s saiu do chat.\n", name)
            }()
        }
    }
}
