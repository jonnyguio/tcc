package main

import (
	"fmt"
	"sync"
)

type Reader struct {
	ID      int
	Count   chan int
	Writers *sync.Mutex
}

func (r *Reader) start(stream []byte, size int) {
	for {
		count := <-r.Count
		if count == 0 {
			r.Writers.Lock()
		}
		r.Count <- count + 1

		fmt.Printf("Reader %d read byte string %v\n", r.ID, stream)

		count = <-r.Count
		if count == 1 {
			r.Writers.Unlock()
		}
		r.Count <- count - 1
	}
}
