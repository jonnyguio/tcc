package main

import (
        "fmt"
        "math/rand"
        "os"
        "strconv"
        "sync"
        "time"
)

func main() {
        if len(os.Args) < 4 {
                fmt.Printf("Usage: %s <number of consumers> <number of producers> <buffer size>\n", os.Args[0])
                os.Exit(1)
        }
        consumers, err := strconv.Atoi(os.Args[1])
        if err != nil {
                fmt.Println("Failed to convert consumer argument as number")
                panic(err)
        }
        producers, err := strconv.Atoi(os.Args[2])
        if err != nil {
                fmt.Println("Failed to convert producer argument as number")
                panic(err)
        }
        bufferSize, err := strconv.Atoi(os.Args[3])
        if err != nil {
                fmt.Println("Failed to convert buffer size argument as number")
                panic(err)
        }
        wg := sync.WaitGroup{}
        rand.Seed(time.Now().UTC().UnixNano())
        streamSize := 32
        stream := make(chan []byte, bufferSize)

        wg.Add(1)
        for i := 0; i < consumers; i++ {
                go consumer(stream, streamSize)
        }
        for i := 0; i < producers; i++ {
                go producer(stream, streamSize)
        }
        wg.Wait()
}