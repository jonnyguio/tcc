package main

import (
	"fmt"
	"sync"
	"time"
)

func consumer(stream chan []byte, streamSize int) {
	streamBytes := make([]byte, streamSize)
	for {
		streamBytes = <-stream
		fmt.Printf("Read from stream %d bytes!\n%v\n", streamSize, streamBytes)
	}
}
