#include <cstdlib>
#include <iostream>
#include <ctime>
#include <chrono>
#include <thread>

int main(int argc, char *argv[]) {
    srand(time(NULL));
	if (argc < 2) {
		std::cout << "Usage: " << argv[0] << " <size of matrix> <number of threads>" << std::endl;
		exit(1);
	}
	int matrix_size = atoi(argv[1]);
	if (matrix_size == 0) {
		std::cout << "Cannot use 0 as matrix size" << std::endl;
		exit(1);		
	}
    int threads = atoi(argv[2]);
	if (threads < 1 || threads > 8) {
		std::cout << "Number of threads must be between 1 and 8" << std::endl;
		exit(1);		
	}
    int **A = (int**) malloc(sizeof(int*) * matrix_size);
    int **B = (int**) malloc(sizeof(int*) * matrix_size);
    int **C = (int**) malloc(sizeof(int*) * matrix_size);
    InitMatrix(A, matrix_size, true);
    InitMatrix(B, matrix_size, true);
    InitMatrix(C, matrix_size, false);

    auto start = std::chrono::high_resolution_clock::now();
    auto ref_threads = new std::thread[matrix_size];
    for (int i = 0; i < threads; i++) {
        ref_threads[i] = std::thread(MultiplyMatrix, A, A, C, matrix_size, threads, i);
    }
    for (int i = 0; i < threads; i++) {
        ref_threads[i].join();
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> dur = end - start;
    std::cout << dur.count() / 1000 << std::endl;
}
