package main

import "fmt"

func main() {
	urls := map[string]string{
		"http":  "http://example.com",
		"https": "https://example.com",
	}
	fmt.Println(urls["http"])
}
