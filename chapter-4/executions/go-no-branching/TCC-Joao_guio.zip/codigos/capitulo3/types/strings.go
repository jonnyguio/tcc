package main

import "fmt"

func main() {
    a := "Hello"
    b := " 世界!\n"
    fmt.Printf("%s", a + b)
}
